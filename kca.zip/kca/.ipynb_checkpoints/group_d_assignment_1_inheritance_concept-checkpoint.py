# INSTITUTION: KCA UNIVERSITY                                                                                 
# COURSE: MSC IN DATA SCIENCE
# UNIT TITLE: COMPUTATIONAL THINKING AND PROGRAMMING FOR DATA SCIENCE
# UNIT CODE: CPP 6102
# TEAM D: Assignment 1

        # MEMBERS
# VICTOR ROKTOK - 25/09881
# STELLA WAIRIMU KIMAMO - 25/02606
# JOHN WAMALWA - 25/02504
# CAROLINE NJERI MUNYIRI - 25/10076

# LECTURER: DR. KEVIN MUGOYE


# ----------------------
# Question One:(Problem Definiton)

# We created a Data Science problrm about a solar company that wants to analyze customer repayment behaviour to check how fast customers repay 
# for purchased product.

# We used a simulated data via numpy to represent real customer and payment info and also used machined learning (LogisticRegression) to
# classify repayment behaviour.

# %%
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# %%
class CustomerData:
    def __init__(self, sample_customers=300):
        self.sample_customers = sample_customers
        self.data = None

    def customer_data_simulation(self):
        np.random.seed(42)

        unit_age_days = np.random.choice([90, 180, 270], size=self.sample_customers, p=[0.5, 0.3, 0.2])

        total_paid = np.random.randint(100, 500, self.sample_customers)
        total_expected = np.random.randint(300, 600, self.sample_customers)
        customer_area = np.random.choice(["Urban", "Rural"], self.sample_customers)
        calls_made_by_agent = np.random.randint(0, 10, self.sample_customers)
        
        # we compute the repayment speed
        repayment_speed = np.round(total_paid / total_expected, 2)

        # defining the repayment_status
        repayment_status = (repayment_speed >= 0.7).astype(int)

        self.data = pd.DataFrame({
            "unit_age_days": unit_age_days,
            "total_paid": total_paid,
            "total_expected": total_expected,
            "customer_area": customer_area,
            "calls_made_by_agent": calls_made_by_agent,
            "repayment_speed": repayment_speed,
            "repayment_status": repayment_status
        })

        return self.data

    def data_process(self):
        df = self.data.copy()
        df = pd.get_dummies(df, columns=["customer_area"], drop_first=True)
        X = df[["total_paid", "total_expected", "calls_made_by_agent", "unit_age_days", "customer_area_Urban"]]
        y = df["repayment_status"]
        return train_test_split(X, y, test_size=0.3, random_state=42)
    
    # We split data into training (70%) and testing (30%) sets
# %%
data = CustomerData(sample_customers=300)
data.customer_data_simulation()
df = data.data
df.head()
df["unit_age_days"].value_counts(normalize=True)*100
# %%

class RepaymentSpeed(CustomerData):
    def __init__(self, sample_customers=300):
        super().__init__(sample_customers)
        self.model = LogisticRegression()

    def model_training(self):
        X_train, X_test, y_train, y_test = self.data_process()
        self.model.fit(X_train, y_train)
        prediction = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, prediction) * 100 
        report = classification_report(y_test, prediction)
        return accuracy, report, X_test, y_test, prediction
    
    # model_training method is used to retrieve the processed data, train the LR model
    # and make the prediction.
    
    def visualize_repayment_by_age(self):
        speed = self.data.groupby("unit_age_days")["repayment_speed"].mean()
        sns.barplot(x=speed.index, y=speed.values)
        plt.title("Average Repayment Speed by Unit Age (Days)")
        plt.xlabel("Unit Age (Days)")
        plt.ylabel("Average Repayment Speed")
        
        # Customers with older units (180 and 270 days) tend to have a slightly higher repayment speed compared to those with newer units (90 days)
        # As units get older, customers seem to repay slightly faster or more consistently.
        # This could mean that customers who have owned units longer are more stable or more reliable in payments.
        
        # Urban Vs Rural
        plt.figure(figsize=(6,4))
        sns.barplot(
        data=self.data,
        x="unit_age_days",
        y="repayment_speed",
        hue="customer_area",)
        plt.title("Average Repayment Speed by Unit Age and Customer Area")
        plt.xlabel("Unit Age (Days)")
        plt.ylabel("Repayment Speed")
        plt.legend(title="Customer Area")
        
        

        
    # visualization helps in identifying the pattern whether customers with newer products repay slower
# %%
repayment = RepaymentSpeed(sample_customers=300)
repayment.customer_data_simulation()
repayment.data.head(20)
repayment.visualize_repayment_by_age()

accuracy, report, X_test, y_test, prediction = repayment.model_training()

accuracy = np.round(repayment.model_training()[0],2)

accuracy

comparison = pd.DataFrame({
    "actual": y_test,
    "predicted": prediction
})

comparison


comparison["correct"] = comparison["actual"] == comparison["predicted"]


# count correct vs incorrect predictions
comparison["correct"].value_counts()

comparison[comparison["correct"] == False]

# percentage of each status
repayment.data["repayment_status"].value_counts(normalize=True) * 100






# summary notes:
# The logistic regression model was trained to classify clients as fast payers or slow payers based on features like total amount paid, expected payment, unit age, number of calls by agents, and customer area.
# On the test set of 90 clients:
# The model correctly predicted 88 out of 90 cases, achieving an accuracy of ~97.8%.
# Only 2 clients were misclassified, which is normal for real-world data.
# Overall, the model demonstrates strong predictive ability, effectively distinguishing between fast and slow payers, with only minor errors.
# This helps the company prioritize follow-ups and improve the collection score.