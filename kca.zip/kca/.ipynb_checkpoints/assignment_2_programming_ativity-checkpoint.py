# INSTITUTION: KCA UNIVERSITY                                                                                 
# COURSE: MSC IN DATA SCIENCE
# UNIT TITLE: COMPUTATIONAL THINKING AND PROGRAMMING FOR DATA SCIENCE
# UNIT CODE: CPP 6102
# TEAM D: Assignment 2

        # MEMBERS
# VICTOR ROKTOK - 25/09881
# STELLA WAIRIMU KIMAMO - 25/02606
# JOHN WAMALWA - 25/02504
# CAROLINE NJERI MUNYIRI - 25/10076

# LECTURER: DR. KEVIN MUGOYE
# DATE OF SUBMISSION: 28TH  NOVEMBER 2025


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# SEQUENCE: Loading and Data Cleaning

# We use header=1 because the raw file has a merged title in the first row
df = pd.read_csv('livestock_population_2018_2021.csv', header=1)


# Column cleaning
df.columns = df.columns.str.strip()

# Rename 'Livestock population 2018' to 'County'
if 'Livestock population 2018' in df.columns:
    df.rename(columns={'Livestock population 2018': 'County'}, inplace=True)

# We remove Unamed columns
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

# Function to convert currency like strings (e.g., "1,200", "-") to floats
def clean_currency(x):
    if isinstance(x, str):
        x = x.strip().replace(',', '').replace('-', '0')
    return pd.to_numeric(x, errors='coerce')

# we apply this cleaning to all columns except 'County'
for col in df.columns:
    if col != 'County':
        df[col] = df[col].apply(clean_currency).fillna(0)

# Rows filtering by removing TOTALS row and any rows where County is missing
data = df[df['County'].notna()].copy()
data = data[data['County'].astype(str).str.upper() != 'TOTALS']

data.shape


# SELECTION & ITERATION

# SELECTION: Filter for High Potential Dairy Counties (> 100k dairy cattle)
# We select a subset of data based on a condition
high_dairy_df = data[data['Cattle_Dairy'] > 100000]

len(high_dairy_df)

# ITERATION: Loop through the results to display them

for index, row in high_dairy_df.head(20).iterrows(): 
    print(f" - {row['County']}: {row['Cattle_Dairy']:,.0f} number of cattles")





# TRANSFORM & CONQUER

# TRANSFORM: Reshape data from Wide (many columns) to Long (County, Species, Count)
leghty_df = pd.melt(data, id_vars=['County'], var_name='Species', value_name='Count')

# CONQUER: Aggregate data to find National Totals (solving the "sum" problem easily)
national_stats = leghty_df.groupby('Species')['Count'].sum().sort_values(ascending=False)


national_stats.head(50)



# MODELING (Clustering & Visualization)

# we select features for clustering
features = ['Cattle_Dairy', 'Cattle_Beef', 'Sheep_Hair', 'Goats_Meat', 'Camels']

# we standardize the data 
scaler = StandardScaler()
X_scaled = scaler.fit_transform(data[features])

# Train K-Means Model (Finding 3 distinct "zones")
kmeans = KMeans(n_clusters=3, random_state=42)
data['Cluster'] = kmeans.fit_predict(X_scaled)

# Dimension Reduction (PCA) for Visualization
# Squashing the 5D data into 2D so we can plot it
pca = PCA(n_components=2)
coords = pca.fit_transform(X_scaled)

# 5. Plotting
plt.figure(figsize=(10, 6))
scatter = plt.scatter(coords[:, 0], coords[:, 1], c=data['Cluster'], cmap='viridis', s=100, alpha=0.7)
plt.title('Livestock Production Zones (K-Means Clustering)')
plt.xlabel('Component 1 (Pastoralism/Scale)')
plt.ylabel('Component 2 (Dairy Intensity)')
plt.colorbar(scatter, label='Cluster ID')
plt.grid(True, linestyle='--', alpha=0.5)

# Annotate outliers for context
for i, txt in enumerate(data['County']):
    if abs(coords[i, 0]) > 2 or abs(coords[i, 1]) > 2:
        plt.annotate(txt, (coords[i, 0], coords[i, 1]), fontsize=9)

plt.show()



# The raw dataset required significant cleaning (handling 'Unnamed' columns and formatting), proving that 'Sequence' is the most critical step in analysis.

# The 'Selection' and 'Iteration' steps revealed that a small number of counties (approx. 15) account for the majority of the country's commercial dairy production.
# Unsupervised learning (K-Means) successfully categorized Kenya's 47 counties into three distinct production clusters, validating the manual categorization done in the earlier steps.