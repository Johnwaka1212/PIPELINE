
# INSTITUTION: KCA UNIVERSITY                                                                                 
# COURSE: MSC IN DATA SCIENCE
# UNIT TITLE: COMPUTATIONAL THINKING AND PROGRAMMING FOR DATA SCIENCE
# UNIT CODE: CPP 6102
# TEAM D: CLASS ACTIVITY

        # MEMBERS
# VICTOR ROKTOK - 25/09881
# STELLA WAIRIMU KIMAMO - 25/02606
# JOHN WAMALWA - 25/02504
# CAROLINE NJERI MUNYIRI - 25/10076

# LECTURER: DR. KEVIN MUGOYE


# A solar company wants to predict whether a customer is likely to default on their solar product loan.
# We have data about payments, unit age, customer area, and agent calls.
# The goal: help the company identify high-risk customers early and act before default happens.

# Transform and conquer occurs anywhere we are creating derived features, simplifying the problem and transforming data

# %%
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


# %%
data = pd.read_csv("customer_loan_repayments.csv")

data.sample(10)

# Data cleaning - turning raw data into cleaned and ready for modelling

data.isnull().sum().sort_values(ascending=False)

data.duplicated().sum()

round(data.isnull().sum()/ len(data) *100,2).sort_values(ascending=False)

data["total_paid"].fillna(data["total_paid"].median(), inplace=True)
data["calls_made_by_agent"].fillna(0, inplace=True)

data["customer_area"] = data["customer_area"].str.strip().str.title()


# Engineered feature - (cleaned data) we created new features to represent customer behaviour

data["total_expected"] = pd.to_numeric(data["total_expected"])
data["total_paid"] = pd.to_numeric(data["total_paid"])

data["repayment_speed"] = data["total_paid"] / data["total_expected"]
data["is_rural"] = (data["customer_area"] == "Rural").astype(int)
data["late_risk"] = (data["last_payment_days_ago"] > 10).astype(int)
data["agent_efficiency"] = data["calls_made_by_agent"] / (data["unit_age_days"] + 1)

# Complex Goal → Known Problem (Problem Reduction) - to predict the likelihood of default and reduced it
#  into a binary classification problem That is into a known machine learning problem

data["default_flag"] = data["payment_status"].map({
    "On-Time": 0,
    "Late": 1,
    "Default": 1
})

# Apply Model → Evaluate & Optimize - we split the data, trained the logistc regression model and evaluated
# it's accuracy. Basically we measure perfomance.

features = ["repayment_speed", "unit_age_days", "is_rural",
            "calls_made_by_agent", "agent_efficiency", "late_risk"]
X = data[features]
y = data["default_flag"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

accuracy_score(y_test, y_pred)

# Create new feature column inside our existing DF to check 3 risk conditions

data["likely_default"] = (
    (data["repayment_speed"] < 0.7) | 
    (data["last_payment_days_ago"] > 20) | 
    (data["calls_made_by_agent"] > 5)       
).astype(int)

data["likely_default"].value_counts(normalize=True) * 100


# Accuracy_score - the accuracy is 100% because we used small dataset.
# About 3 in 10 customers are at risk of default, while 7 in 10 are on track.


# %%
